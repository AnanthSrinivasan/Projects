//---
#ifndef FlyBehaviorH
#define FlyBehaviorH
//---

class FlyBehavior
{

public:
	virtual void fly() const{};
};

#endif
