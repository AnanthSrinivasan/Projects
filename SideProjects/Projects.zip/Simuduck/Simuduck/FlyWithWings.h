//---
#ifndef FlyWithWingsH
#define FlyWithWingsH
//---

#include "FlyBehavior.h"

class FlyWithWings : public FlyBehavior 
{
public:
	void fly() const;
};

#endif
