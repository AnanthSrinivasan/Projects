//---
#ifndef QuackSqueakH
#define QuackSqueakH
//---

#include "QuackBehavior.h"

class QuackSqueak : public QuackBehavior 
{
public:
	void quack() const;
};

#endif
