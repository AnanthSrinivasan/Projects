#include <iostream>
#include "FlyRocketPowered.h"

void FlyRocketPowered::fly() const
{
	std::cout << "Hooo Hooo I am a Rocket Powered duck :" << std::endl;
}
