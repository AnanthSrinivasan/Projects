//---
#ifndef ModelDuckH
#define ModelDuckH
//---

#include "Duck.h"

class ModelDuck : public Duck
{

public:
	ModelDuck();
	void display();
	void swim();
};

#endif
