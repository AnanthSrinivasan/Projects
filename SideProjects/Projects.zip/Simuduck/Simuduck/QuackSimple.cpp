#include <iostream>
#include "QuackSimple.h"

void QuackSimple::quack() const
{
	std::cout << "I am a Simple duck :" << std::endl;
}
