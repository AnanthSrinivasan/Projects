//---
#ifndef FlyRocketPoweredH
#define FlyRocketPoweredH
//---

#include "FlyBehavior.h"

class FlyRocketPowered : public FlyBehavior 
{
public:
	void fly() const;
};

#endif
