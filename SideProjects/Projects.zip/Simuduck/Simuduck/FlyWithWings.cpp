#include <iostream>
#include "FlyWithWings.h"

void FlyWithWings::fly() const
{
	std::cout << "I am the flying duck with Wings :" << std::endl;
}
