#include <iostream>
#include "QuackSqueak.h"

void QuackSqueak::quack() const
{
	std::cout << "I am a Squeaking duck :" << std::endl;
}
