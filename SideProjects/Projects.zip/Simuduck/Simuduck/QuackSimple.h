//---
#ifndef QuackSimpleH
#define QuackSimpleH
//---

#include "QuackBehavior.h"

class QuackSimple : public QuackBehavior 
{
public:
	void quack() const;
};

#endif
