//---
#ifndef QuackBehaviorH
#define QuackBehaviorH
//---

class QuackBehavior
{

public:
	virtual void quack() const{};
};

#endif
