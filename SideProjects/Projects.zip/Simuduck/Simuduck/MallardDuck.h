//---
#ifndef MallardDuckH
#define MallardDuckH
//---

#include "Duck.h"

class MallardDuck : public Duck
{

public:
	MallardDuck();
	void display();
	void swim();
};

#endif
