#pragma once
#include "weaponbehavior.h"

class SwordBehavior :
	public WeaponBehavior
{
public:
	void useWeapon() const;
};
