#pragma once
#include "character.h"

class Bishop :
	public Character
{
public:
	Bishop(void);
	~Bishop(void);
};
