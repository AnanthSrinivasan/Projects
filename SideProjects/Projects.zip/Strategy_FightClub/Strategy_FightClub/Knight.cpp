#include "Knight.h"
#include "BABehavior.h"

Knight::Knight(void)
{
	m_weapon = new BABehavior();
}

Knight::~Knight(void)
{
}
