#pragma once
#include "character.h"

class King :
	public Character
{
public:
	King(void);
	~King(void);
};
