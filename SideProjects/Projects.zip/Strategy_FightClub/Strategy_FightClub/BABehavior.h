#pragma once
#include "weaponbehavior.h"

class BABehavior :
	public WeaponBehavior
{
public:
	void useWeapon() const;
};
