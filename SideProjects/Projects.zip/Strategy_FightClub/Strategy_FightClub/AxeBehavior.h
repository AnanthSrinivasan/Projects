#pragma once
#include "weaponbehavior.h"

class AxeBehavior :
	public WeaponBehavior
{
public:
	void useWeapon() const;
};
