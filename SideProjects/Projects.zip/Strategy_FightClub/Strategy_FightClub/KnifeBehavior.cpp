#include <iostream>
#include "KnifeBehavior.h"

void KnifeBehavior::useWeapon() const
{
	std::cout << "I am using Knife to fight. " << std::endl;
}