#include "Bishop.h"
#include "AxeBehavior.h"

Bishop::Bishop(void)
{
	m_weapon = new AxeBehavior();
}

Bishop::~Bishop(void)
{
}
