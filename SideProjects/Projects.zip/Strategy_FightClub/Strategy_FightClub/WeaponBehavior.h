#pragma once

class WeaponBehavior
{
public:
	virtual void useWeapon() const{};
};
