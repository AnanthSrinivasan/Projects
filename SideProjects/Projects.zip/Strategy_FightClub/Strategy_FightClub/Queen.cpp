#include "Queen.h"
#include "KnifeBehavior.h"

Queen::Queen(void)
{
	m_weapon = new KnifeBehavior();
}

Queen::~Queen(void)
{
}
