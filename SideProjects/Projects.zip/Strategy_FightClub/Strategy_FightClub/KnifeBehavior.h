#pragma once
#include "weaponbehavior.h"

class KnifeBehavior :
	public WeaponBehavior
{
public:
	void useWeapon() const;
};
