#include <iostream>
#include "SwordBehavior.h"

void SwordBehavior::useWeapon() const
{
	std::cout << "I am using Sword to fight. " << std::endl;
}