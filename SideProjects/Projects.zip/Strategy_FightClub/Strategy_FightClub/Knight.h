#pragma once
#include "character.h"

class Knight :
	public Character
{
public:
	Knight(void);
	~Knight(void);
};
