#pragma once
#include "character.h"

class Queen :
	public Character
{
public:
	Queen(void);
	~Queen(void);
};
