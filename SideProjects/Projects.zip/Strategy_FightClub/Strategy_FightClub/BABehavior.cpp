#include <iostream>
#include "BABehavior.h"

void BABehavior::useWeapon() const
{
	std::cout << "I am using Bow and Arrow to Fight. " << std::endl;
}