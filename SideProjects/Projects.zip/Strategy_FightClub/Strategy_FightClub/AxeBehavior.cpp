#include <iostream>
#include "AxeBehavior.h"

void AxeBehavior::useWeapon() const
{
	std::cout << "I am using an Axe to Fight. " << std::endl;
}