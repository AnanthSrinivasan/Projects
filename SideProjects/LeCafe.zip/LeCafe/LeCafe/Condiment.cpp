#include "Condiment.h"

Condiment::Condiment(Beverage * bev) : beverage(bev)
{
}

Condiment::~Condiment(void)
{
}
