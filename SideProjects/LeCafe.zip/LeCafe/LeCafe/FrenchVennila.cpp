#include "FrenchVennila.h"
#include <iostream>

FrenchVennila::FrenchVennila(void)
{
	description = "French Vennilla";
}

FrenchVennila::~FrenchVennila(void)
{
}

double FrenchVennila::cost()
{
	return 1.00;
}
