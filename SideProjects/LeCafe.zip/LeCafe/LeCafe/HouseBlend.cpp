#include "HouseBlend.h"
#include <iostream>

HouseBlend::HouseBlend(void)
{
	description = "House Blend";
}

HouseBlend::~HouseBlend(void)
{
}

double HouseBlend::cost()
{
	return 2.00;
}